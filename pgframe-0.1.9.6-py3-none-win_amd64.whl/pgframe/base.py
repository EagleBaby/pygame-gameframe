from pgframe.constant import *
from pgframe.exception import *
import xml.etree.ElementTree as ele
import math
import sys
import os


class Tick(object):
    def __init__(self, tim):
        """
        设置间隔工作机制
        :param tim: int 间隔帧
        """
        self.tim_set = tim
        self.tim_rec = 0
        self._able = True

    def GetStatus(self):
        return self._able

    def Enabled(self):
        self._able = True

    def Disabled(self):
        self._able = False

    def Reset(self):
        """
        重置记录
        :return: None
        """
        self.tim_rec = 0

    def SetTim(self, tim, reset=False):
        """
        设置间隔
        :param tim: int 间隔数
        :param reset: Bool 是否重置
        :return: None
        """
        if reset:
            self.Reset()
        self.tim_set = tim

    def Get(self):
        """
        获得时钟剩余时间
        ：return: int 剩余时间
        """
        return self.tim_rec

    def Set(self, value):
        self.tim_rec = value

    def tick(self):
        """
        时钟tick
        :return: Bool 是否达到时间点
        """
        if self._able:
            if self.tim_rec >= self.tim_set:
                self.tim_rec = 0
                return True
            else:
                self.tim_rec += 1
        return False

    def __call__(self, *args, **kwargs):
        return self.tick()


def IsClickActive(aim_view, pos):
    aim = aim_view.GetPos()
    if aim:
        size = aim_view.GetSize()
        return IsInArea(pos, aim, size)


def IsFocusActive(aim_view, pos):
    aim = aim_view.GetPos()
    if aim:
        size = aim_view.GetSize()
        return IsInArea(pos, aim, size)


def IsInArea(pos, area_pos, area_size):
    return area_pos[0] < pos[0] < area_pos[0] + area_size[0] and area_pos[1] < pos[1] < area_pos[1] + area_size[1]


def IsInCircle(pos, circle_center, circle_radius):
    return GetPointsDistance(pos, circle_center) < circle_radius


def GetPointsDistance(pos1, pos2):
    return ((pos1[0] - pos2[0]) ** 2 + (pos1[1] - pos2[1]) ** 2) ** .5


def GetDirect(self_pos, aim_pos):
    """
    y轴向下
    :param self_pos:
    :param aim_pos:
    :return:
    """
    if self_pos[0] > aim_pos[0]:
        a = Vector(0, 1)
        direct = 180
    else:
        a = Vector(0, -1)
        direct = 0
    b = Vector(aim_pos[0] - self_pos[0], aim_pos[1] - self_pos[1])
    return int(math.degrees(math.acos(a.GetCos(b)))) + direct


def AnalyzeVersion(pgf_path):
    """
    分析已有的可用版本
    """
    ...


class Vector(object):
    def __init__(self, *array):
        self.array = array

    def Dot(self, other):
        if len(self.array) != len(other.array):
            raise (Exception("只有同维向量才能做点积."))
        temp = 0
        for i, j in zip(self.array, other.array):
            temp += i * j
        return temp

    def Length(self):
        temp = 0
        for i in self.array:
            temp += i ** 2
        return temp ** .5

    def __getitem__(self, item):
        return self.array[item]

    def Multiply(self, other):
        return self.Length() * other.Length() * math.sin(math.acos(self.GetCos(2)))

    def Add(self, other):
        temp = []
        for i, j in zip(self.array, other.array):
            temp += [i + j]
        return Vector(temp)

    def Sub(self, other):
        temp = []
        for i, j in zip(self.array, other.array):
            temp += [i - j]
        return Vector(temp)

    def __sub__(self, other):
        return self.Sub(other)

    def __add__(self, other):
        return self.Add(other)

    def __mul__(self, other):
        return self.Multiply(other)

    def __eq__(self, other):
        return self.array == other.array

    def __len__(self):
        return self.Length()

    def GetCos(self, other):
        try:
            return self.Dot(other) / (self.Length() * other.Length())
        except ZeroDivisionError:
            return 1


def GetRectSide(collide, collide_):
    """
    获取是collide的那个面与collide_发生碰撞
    :param collide: collide self
    :param collide_: collide other
    :return: "top""bottom""left""right"
    """
    rect = collide.GetRect()
    rect_ = collide_.GetRect()
    temp = rect.clip(rect_)
    pos = collide.inst.GetPos()
    if temp.width > temp.height:
        if rect.centery > rect_.bottom:
            collide.inst.SetPos((collide.inst.GetPos()[0], rect_.bottom - 1))
            return "top"
        else:
            collide.inst.SetPos((collide.inst.GetPos()[0], rect_.top - rect.height + 1))
            return "bottom"
    elif temp.width < temp.height:
        if rect.centerx > rect_.right:
            collide.inst.SetPos((rect_.right - 1, collide.inst.GetPos()[1]))
            return "left"
        else:
            collide.inst.SetPos((rect_.left - rect.width + 1, collide.inst.GetPos()[1]))
            return "right"
    else:
        return None


def UpdateModelData(data, auto=False):
    if not (data.st.AUTO_UPDATE_MODEL or auto):
        return
    for model in os.listdir(data.st.PATH_SET["datum"]):
        if os.path.isdir(os.path.join(data.st.PATH_SET["datum"], model)):
            for datum in os.listdir(os.path.join(data.st.PATH_SET["datum"], model)):
                if datum[len(datum) - 5:] == ".data":
                    datum = datum[:len(datum) - 5]
                    getattr(data.md, model)(datum).save()


def CheckEnvironment():
    import platform
    sys = platform.system()  # windows or other
    if sys != "Windows":
        raise UnCompatiblePlatform(sys)


def BuildXmlFromDict(data: dict, path: str, table: dict):
    """
    :param data: dict 待转化的数据
    :param path: str xml文件路径
    :param table: dict 自动转化已有值
    """
    import re

    def pretty_xml(element, indent, newline, level=0):  # elemnt为传进来的Elment类，参数indent用于缩进，newline用于换行
        if element:  # 判断element是否有子元素
            if (element.text is None) or element.text.isspace():  # 如果element的text没有内容
                element.text = newline + indent * (level + 1)
            else:
                element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * (level + 1)
                # else:  # 此处两行如果把注释去掉，Element的text也会另起一行
                # element.text = newline + indent * (level + 1) + element.text.strip() + newline + indent * level
        temp = list(element)  # 将element转成list
        for subelement in temp:
            if temp.index(subelement) < (len(temp) - 1):  # 如果不是list的最后一个元素，说明下一个行是同级别元素的起始，缩进应一致
                subelement.tail = newline + indent * (level + 1)
            else:  # 如果是list的最后一个元素， 说明下一行是母元素的结束，缩进应该少一个
                subelement.tail = newline + indent * level
            pretty_xml(subelement, indent, newline, level=level + 1)  # 对子元素进行递归操作

    def AddSub(inst, _d, _t):
        for k in _d:
            if isinstance(_d[k], dict):
                sub_node = ele.SubElement(inst, k)
                AddSub(sub_node, _d[k], _t)
            else:
                node = ele.SubElement(inst, k)
                if _d[k] in table:
                    node.text = str(table[_d[k]])
                else:
                    node.text = _d[k]

    if len(data) > 1:
        root = ele.Element("data")
    else:
        root = ele.Element(list(data)[0])
        data = data[list(data)[0]]

    AddSub(root, data, table)
    tree = ele.ElementTree(root)
    pretty_xml(root, "\t", "\n")
    tree.write(path, encoding="utf-8")


def BuildProjectInfo(path, ver=AUTO):
    import getpass
    import time
    ver = str(ver)
    t = time.localtime()
    table = {
        "$version": ver[:-1] + "." + ver[-1],
        "$name": os.path.basename(path),
        "$user": getpass.getuser(),
        "$time": "{}-{}-{} {}:{}:{}".format(*t[:6]),
    }
    BuildXmlFromDict(NEW_PROJECT_INFOS, os.path.join(path, XML_FILE), table)


def ParseProjectInfo(path):
    tree = ele.ElementTree(file=path)
    temp = TEMP()
    for e in tree.iter():
        setattr(temp, e.tag, e.text)
    return temp


def ExportAuthorInfo(path, data):
    if not data:
        txt = "Missing building info."
    else:
        txt = "Readme File\n"
        txt += "File Version is " + data[VERSION] + "\n"
        txt += "Powered by " + data[CREATOR] + "\n"
        txt += "Created at " + data[CRTIME] + "\n"
        txt += "Created by " + data[AUTHOR] + "\n"
    with open(path, "w") as f:
        f.write(txt)


def CopySourceFiles(path, aim):
    """

    :param path:str 项目路径
    :param aim:str 输出路径
    :return:
    """
    import shutil
    import sys
    sys.path.insert(0, path)
    import settings as st
    data = []
    data += [getattr(st, "DATAPATH", None)]
    data += [getattr(st, "LOGPATH", None)]
    data += [getattr(st, "TITLE_ICON", None)]
    if data[-1]:
        p = getattr(st, "PATH", None)
        if p:
            data[-1] = os.path.join(p, data[-1])
    data += getattr(st, "SOURCES", [None])


    # 检查:
    if not getattr(st, "TITLE_ICON", None):
        print("failed to copy source files because of lost TITLE_ICON, please try to copy source files manually.")
        return
    # print(data)
    # 开始拷贝
    for item in data:
        if item and os.path.exists(item):
            item = os.path.basename(item)
            fr, to = os.path.join(path, item), os.path.join(aim, item)
            # print(fr, "\n", to)
            if not os.path.exists(fr):
                print("-> source copy filed: aim - {} do not exist")
                continue
            if os.path.isfile(fr):
                if os.path.exists(to):
                    os.remove(to)
                shutil.copy(fr, to)
            elif os.path.isdir(fr):
                if os.path.exists(to):
                    shutil.rmtree(to)
                shutil.copytree(fr, to)
            else:
                print("-> failed to copy file: Unknown Type - {}".format(fr))


if __name__ == '__main__':
    CopySourceFiles(r"C:\Users\bluesky\Desktop\test", r"C:\Users\bluesky\Desktop\test\exported\test")
    # BuildProjectInfo(r"C:\Users\bluesky\Desktop")
