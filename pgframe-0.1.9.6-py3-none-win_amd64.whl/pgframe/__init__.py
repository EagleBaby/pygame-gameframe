import os
import shutil
import sys
import time

"""
采用mcv模式
m：
一个继承model的class一个数据类型
一个class实例化，一条数据
被其他模块调用
c：
一个继承ctrl的class一种控制
在view里调用LogController激活控制器
v:
一个继承view的class一种视图
被其他视图通过AddView加载或以主界面形式被pgframe调用(run中填写view的名称并且将此view的auto设为True)

其他：
c(Components):
一个继承components的class一种组件
调用AddComponents为你的view添加组件

以上模式简称mcv-c
除m外，cv-c中任一class实例对象中含有.data和.inst属性，通过他们可以访问到全局数据和上级对象

全局数据中以System_Support_Part_开头的全为系统方法；以system_support_part_开头的全为系统属性，用户不应随意调用它们,随意调用这些方法可能会导致程序崩溃
而全局数据中以Support_Part_开头的为用户可调用方法；以support_part_开头的为用户可调用属性，虽然这些方法和属性用户可以使用，但仍然不建议使用他们，因为这些方法仍然位于较底层并且用于底层的debug
建议用户在.data中保存数据时不要以support_part_或system_support_part_作为数据名称的开头，避免重名覆盖
总之，程序项目编写几乎不需要用户使用全局数据中(.data)的方法和属性，对用户而言.data的作用就只是存放全局数据。例如model实例化对象建议放在.data中，便于全局调用

components中内置了Pic，Collide组件
controllers中内置了Click，Focus控制器
"""
from pgframe.base import *
import pgframe.main as main

pgframe_dir = os.path.dirname(__file__)
os.environ['PATH'] = os.environ['PATH'] + ';' + pgframe_dir
info = 'packaging pgframe 0.1.9.3'


def AddSourceData(path):
    need = SOURCES
    for pt in need:
        if os.path.isfile(os.path.join(pgframe_dir, pt)):
            shutil.copy(os.path.join(pgframe_dir, pt), os.path.join(path, pt))
        else:
            shutil.copytree(os.path.join(pgframe_dir, pt), os.path.join(path, pt))


def ExportProject(path, version=1.0):
    version = str(version).replace(".", "")
    if os.path.isfile(path):  # 文件时报错
        raise NotDir(path)
    if os.path.exists(path):  # 文件夹存在时删除该文件夹
        shutil.rmtree(path)
    shutil.copytree(os.path.join(pgframe_dir, EXPORTED, str(version)), path)
    AddSourceData(path)  # 添加资源文件(比如图片和音乐)
    BuildProjectInfo(path, version)


def GetGame(models, controllers, views, components, events, settings):
    game = main.main_init(models, controllers, views, components, events, settings)
    game.data.log.info("Preparing...")
    # 这里可以放其他的初始化

    game.data.log.info("PreGame is ready now.")
    return game


def ShellCmd_New(args=None):
    def fn():
        if args and args.path != " ":
            path = args.path
            if os.path.exists(path):
                if os.listdir(path):
                    get = input("目录{}下已有文件，本操作将删除该目录下所有文件，要继续吗?(y/n)".format(path))
                    if get != "y":
                        return
        else:
            path = input("请输入目标路径:\n(若路径存在,则该路径下所有文件将被清理,请确保路径不是根目录或有文件的目录)\n")
        if args:
            version = args.version
        else:
            version = input("请输入您想创建的pgframe工程版本(可选，默认为最新" + str(1.0) + "):")
        if version != "":
            try:
                float(version)
            except:
                print("-->Error:Version can not be a non-int<--")
                return
            print("正在生成项目...")
            ExportProject(path, float(version))
        else:
            print("正在生成项目...")
            ExportProject(path)
        print("-->Successful:Project at " + path + " be successfully created.<--")

    fn()


def ShellCmd_Build(args=None):
    def fn():
        def temp001(_path, _aim, _data):  # 环境和信息处理
            print("正在拷贝运行环境...")
            CopySourceFiles(_path, _aim)
            print("正在生成文件信息...")
            ExportAuthorInfo(os.path.join(_aim, "readme.txt"), _data)

        def struct001(_path, _aim):  # 检查path和aim
            if not os.path.exists(_aim):
                os.mkdir(_aim)
            else:
                shutil.rmtree(_aim)
                os.mkdir(_aim)
            if not os.path.isdir(_path):
                raise NotDir(_path)

        def struct002():  # 进行exe打包的操作
            upx = ""
            if data:
                if data[UPX] and data[UPX] != "<disable>":
                    if os.path.exists(data[UPX]) and data[UPX][-3:] == "exe":
                        upx = " --upx-dir " + data[UPX]
                    else:
                        print("-> upx:{} is unavailable".format(data[UPX]))

            if not upx and data and data[UPX] != "<disable>":
                print("-> pgframe will try to use the default upx.")
                _upx = os.path.join(pgframe_dir, UPX_DEFAULT)
                if os.path.exists(_upx) and _upx[-3:] == "exe":
                    upx = " --upx-dir " + _upx
                else:
                    print("-> filed to link the default upx.")
                    print("-> now will build without upx.")
            print()  # 空一行

            user_packages = " -p " + path

            cmd = "pyinstaller " + os.path.join(path, "main.py") + " " + asf + asw + asi + " --distpath=" + aim + upx + user_packages  # 命令
            if os.path.exists(os.path.join(aim, exename)):  # 清理文件夹
                shutil.rmtree(os.path.join(aim, exename))
                print("编译环境清理中，请稍后...")
                time.sleep(1)
            print("please wait for cmd window close...")
            # print(cmd)
            get = os.system(cmd)
            print("system info: ", get)

        def struct003():  # exe打包失败时的行为
            if not (os.path.exists(os.path.join(aim, "main.exe")) or (
                    os.path.exists(os.path.join(aim, "main")) and os.path.exists(
                os.path.join(aim, "main", "pygame")))):
                try:
                    exec("import pyinstall", {})
                except:
                    print("failed to build, for do not find package pyinstaller, please use 'pip install pyinstaller', and then try again.")
                    return False
                print(
                    "failed to build, if you are the first time meet this situation, it may due to that the antivirus software is not closed or the project file is occupied, please try again after change that")
                return False
            return True

        def struct004():  # 缺失build.xml时的行为
            if not os.path.exists(os.path.join(path, "build.xml")):
                print("-> failed to load build.xml")
                get = input("due to loss build file, it may build inappropriately, do you want to continue?(y/n)")
                if get == "y":
                    return None
                else:
                    print("-> User cancelled operation.")
                    return False
            return True

        if args and args.path != " ":
            path = args.path
        else:
            path = input("请输入待导出的项目路径(导出期间请关闭杀毒软件并关闭项目):\n")
        aim = os.path.join(path, "exported")
        struct001(path, aim)

        # 解析build文件
        _rtn = struct004()  # 缺失build.xml时的行为
        print()  # 空一行, 执行完了004
        if _rtn is None:
            asf, asw, asi = "", "", ""
            exename = "main"
            data = None
        elif not _rtn:
            return
        else:
            data = ParseProjectInfo(os.path.join(path, "build.xml"))
            exename = data[EXENAME] if data[EXENAME] else "main"
            asf = "-F " if data[AS_F] and data[AS_F].lower() == "y" else ""
            asw = "-w " if data[AS_W] and data[AS_W].lower() == "y" else ""
            asi = "-i " + os.path.join(path, data[ICOPATH]) if data[ICOPATH] and data[ICOPATH] != "<disable>" else ""
        if asi and asi[-3:].lower() != "ico":
            print(ICOPATH, " {} is not a .ico file, you should transfer it to .ico file first or set {} as ''.".format(asi, ICOPATH))
            asi = ""
        if not asi:
            print("-> pgframe will try to use the default ico file.")
            if not os.path.exists(os.path.join(pgframe_dir, "game.ico")):
                print("-> filed to load the default ico file.")
                print("-> now will build with pyinstaller ico.")
                asi = ""
            else:
                asi = "-i " + os.path.join(pgframe_dir, "game.ico")
            print()  # 空一行

        struct002()  # 进行exe打包的操作
        # - 判断是否成功
        if not struct003():  # exe打包失败时的行为
            return
        print()  # 空一行, 执行完了003
        # pyinstaller会自动到aim下打包
        # 拷贝数据
        if asf != "":  # 为单文件模式
            temp001(path, aim, data)
        else:
            os.rename(os.path.join(aim, "main"), os.path.join(aim, exename))
            os.rename(os.path.join(aim, exename, "main.exe"), os.path.join(aim, exename, exename + ".exe"))
            temp001(path, os.path.join(aim, exename), data)
        print("-- <build successfully finish> --")

    fn()


def cmd():
    import argparse
    # 创建解析器
    parser = argparse.ArgumentParser()

    # 添加位置参数(positional arguments)
    parser.add_argument('command', default="shell", type=str, help='What type of command want pgframe do. Use "pgframe help" to get help.',
                        choices=["help", "new", "build", "export", "quit", "exit", "end", "version", "support"])
    parser.add_argument('path', nargs='?', default=" ", type=str, help='Project path for some commands.')
    parser.add_argument('--version', "-v", default="1.0", type=str, help='When new project, the version you want.', choices=["1.0"])
    args = parser.parse_args()
    state = args.command != "shell"
    shell(args.command if state else None, args if state else None)


def shell(cmd=None, args=None):
    if not cmd: raise Exception("请在cmd中 使用'pgframe'来调用它")
    help_doc = "\nhelp    查看帮助信息\nquit,exit,shutdown  退出shell\nnew    新建项目\nbuild,export    将项目进行打包\n"
    while True:
        if not cmd:
            temp = input("输入命令:\n")
        else:
            temp = cmd
        temp = temp.lower()
        if temp == "help":
            print(help_doc)
        elif temp == "support":
            os.system(os.path.join(pgframe_dir, "support.bat"))
        elif temp == "version":
            print("-- PgFrame {} --".format(package_version))
        elif temp in ["quit", "exit", "shutdown"]:
            break
        elif temp == "new":
            ShellCmd_New(args)
        elif temp in ["export", "build"]:
            ShellCmd_Build(args)
        else:
            print("\n无效的命令(输入help命令可以查看帮助).\n")
        if cmd:
            break


if __name__ == '__main__':
    print(sys.path)
    shell()
