# 这是一个用户文件
import random

from pgframe.views import View, Anim, Button, Label


class Root(View):
    auto = True
    layer = -1

    def Loading(self, **kwargs):
        self.AddView(Test2)


class Test(View):
    def Loading(self, **kwargs):
        self.AddView(Label, text="hello,world!", bold=True, font=(None, 60), fg=(255, 195, 25),
                     left=100, top=100, width=200, height=100)
        # self.t_id = self.LogController("Test")


class Test2(View):
    def Loading(self, **kwargs):
        self.SetSize((64, 64))
        self.SetPos((200, 200))
        self.AddComponent("Pic",ArtDef="test", scale=25)
        self.AddComponent("Locomotor", border="lock", sign="motor")
        self.LogController("Up")
        self.LogController("Down")
        self.LogController("Left")
        self.LogController("Right")
