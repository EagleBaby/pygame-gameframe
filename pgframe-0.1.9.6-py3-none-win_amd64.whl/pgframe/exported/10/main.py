# 这是一个用户文件
from pgframe import GetGame
import events
import models
import settings
import views
import components
import controllers

Game = GetGame(models, controllers, views, components, events, settings)

Game.run("Root")
