import tkinter as tk
import warnings

import win32con
import win32gui
from pgframe.support import *  # pg, display, draw, transform,Data

CheckEnvironment()
warnings.filterwarnings("ignore")

data = Data()


class Game(object):
    def __init__(self, data, models=None, controlors=None, views=None, components=None, events=None, settings=None):
        if models is None:
            models = md
        if controlors is None:
            controlors = ct
        if views is None:
            views = vw
        if components is None:
            components = cp
        if settings is None:
            settings = st
        if events is None:
            events = ev
        self.data = data
        self.data.inst = self
        self.data.md = models
        self.data.st = settings
        self.data.ct = controlors
        self.data.vw = views
        self.data.cp = components
        self.data.ev = events
        self.data.clock = pg.time.Clock()

        self.data.log.Active()
        if not hasattr(models, "System_Model_Part_Init"):
            raise (Exception("In your models.py,you need \"from pgframe.models import *\"."))

    def SetWindowCenter(self):
        old_vision_adjust = self.data.st.Window_Center_Adjust if hasattr(self.data.st, '') else (0, 38)
        temp = tk.Tk()
        s_w = temp.winfo_screenwidth()
        s_h = temp.winfo_screenheight()
        temp.destroy()
        tx, ty = self.data.st.DEFAULT_WINDOW_SIZE
        x, y, a, b = int((s_w - tx) / 2), int((s_h - ty) / 2), tx, ty
        hwnd = win32gui.FindWindow(None, self.data.st.TITLE_CAPTION)
        win32gui.SetWindowPos(hwnd, None, x, y, a + old_vision_adjust[0], b + old_vision_adjust[1],
                              win32con.SWP_SHOWWINDOW)

    def run(self, window_name):
        self.data.log.info("Loading..." + LOG_SEPARATE)
        try:
            pg.init()
            self.data.screen = display.set_mode(self.data.st.DEFAULT_WINDOW_SIZE)
            self.data.System_GetThingsReady(srt_window=window_name)
            self.win = self.data.SysGetWindow()
            display.set_caption(self.data.st.TITLE_CAPTION)
            display.set_icon(image.load(self.data.st.TITLE_ICON))
            self.SetWindowCenter()
        except Exception as err:
            self.data.log.error("Can not run Game because:")
            raise err
        self.data.log.info("All Game Data Loaded. Now will start the mainloop:")
        try:
            quit_info = self.mainloop()
        except Exception as err:
            self.data.log.error("\nWhile Game running, an unexpected error happen:")
            quit_info = 404
            raise err

        self.data.log.info("Game Exit with code {}.".format(quit_info))
        sys.exit(quit_info)

    def mainloop(self):
        while True:
            self.data.System_TickSetProcess()
            for eve in pg.event.get():
                if eve.type == pg.QUIT:
                    self.data.log.info("Game jump out mainloop by user quit.", exc_info=False)
                    return 0
                self.data.SysGetCtrlManage().AddQueue("CtrlHandler", data=self.data, eve=eve)
                self.data.SysGetEveManage().AddQueue("EventHandler", data=self.data, eve=eve)
            self.data.SysGetEveManage().AddQueue("PeriodTaskHandler", data=self.data)
            self.data.SysGetWinManage().AddQueue("UpdateGameWindow")
            self.data.clock.tick(self.data.st.FREQUENCY)
            self.data.SysGetSoundManage().AddQueue("MusicQueueHandler")
            self.data.SysGetCamera().CameraUpdate()


def main_init(models, controlors, views, components, events, settings):
    if not data.game___init__:
        data.game___init__ = True
        return Game(data, models, controlors, views, components, events, settings)
    else:
        data.log.warning("pgframe has already __init__ed.")


if __name__ == "__main__":
    a = main_init(None, None, None, None, None, None)
    a.run("Root")
