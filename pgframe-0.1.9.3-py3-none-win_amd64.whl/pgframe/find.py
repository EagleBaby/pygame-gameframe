import os
p = os.getcwd()
data = []
get = input("请指明忽略关键字(回车跳过此步):")
if not get:
    get = "极小概率出现这样一个字符串HHHHEEEELLLLLLLLOOOOWWWWOOOORRRRLLLLDDDD!!!!"

for file in os.listdir():
    if file[-3:] == ".py":
        with open(os.path.join(p, file), "r", encoding="utf-8") as f:
            for line in f.read().split("\n"):
                if "import" in line:
                    while line[0] == " ":
                        line = line[1:]
                    if line[:6] == "import" or line[:4] == "from":
                        if get not in line:
                            data += [line]

data = set(data)
if os.path.exists("req.txt"): os.remove("req.txt")
f = open("req.txt", "a")
for t in data:
    f.write(t + "\n")
f.close()
