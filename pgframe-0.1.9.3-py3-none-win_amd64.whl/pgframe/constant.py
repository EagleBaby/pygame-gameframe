package_name = "- PGFrame -"
package_version = "0.1.9.3"

AUTO = -255

"""
项目创建相关:
"""
EXPORTED = "exported"  # 可导出的文件夹名称
SOURCES = ["game.png", "data", "log"]
XML_FILE = "build.xml"

VERSION = 'Version'
CREATOR = 'Creator'
CRTIME = 'CrTime'
AUTHOR = 'Author'
ICOPATH = 'IcoPath'
EXENAME = 'ExeName'
AS_W = 'HideCmd'
AS_F = 'AsFile'
UPX = "Upx"
UPX_DEFAULT = "upx_win64/upx.exe"
NEW_PROJECT_INFOS = {
    "data": {
        "VersionInfo": {
            VERSION: "$version",
            CREATOR: "{} {}".format(package_name, package_version),
            CRTIME: "$time",
            AUTHOR: "$user",
        },
        "ExportInfo": {
            ICOPATH: "<disable>",
            EXENAME: "$name",
            AS_W: "y",
            AS_F: 'n',
            UPX: "<disable>",

        },
    }
}

"""
与程序有关
"""
LOG_FORMATTER = "%(asctime)s - %(message)s"
LOG_SEPARATE = "\n-----------------------------------------------------------"


class TEMP(object):
    def __getitem__(self, item):
        return getattr(self, item, None)
