import time
import tkinter.messagebox as message
import logging
import time

try:
    class FalseData:
        pass


    import pgframe.user_models as md
    import pgframe.user_settings as st

    _data = FalseData()
    _data.md, _data.st = md, st
    md.System_Model_Part_Init(_data)
    import pgframe.user_views as vw
    import pgframe.user_components as cp
    import pgframe.user_controllers as ct
    import pgframe.user_events as ev
except Exception as error:
    message.showerror("你的某个文件出现了错误：", "在一个用户文件中有一个错误:\n" + str(error))
from pgframe.core import *
from threading import *


class GameThread(Thread):
    def __init__(self, name=None, daemon=True, tick=60):
        super().__init__(name=name, daemon=daemon)
        self.queue = []  # (name:kwargs)
        self.tick = tick
        self.delta = 1 / self.tick
        self.ready = False

    def SetTick(self, tick):
        self.tick = tick
        self.delta = 1 / self.tick

    def GetQueue(self):
        if self.queue:
            temp = self.queue
            self.queue = []
            return temp
        return self.queue

    def AddQueue(self, task_name, *task_args, **task_parm):
        self.queue.append((task_name, task_args, task_parm))

    def Ready(self):
        self.ready = True

    def run(self):
        while True:
            time.sleep(self.delta)
            if self.ready:
                for i in self.GetQueue():
                    getattr(self, i[0])(*i[1], **i[2])


class Data(object):
    game___init__ = False
    BaseInfo = list(["md", "st", "vw", "cp", "ct", "ev"])
    screen = None
    inst = None
    md = None
    st = None
    vw = None
    cp = None
    ct = None
    ev = None

    class System_GroupManage(GameThread):
        def __init__(self, data):
            super().__init__(name="group_thread", daemon=True)
            self.data = data
            self.group = {}

        def CreateNewGroup(self, group_name):
            self.group[group_name] = pg.sprite.Group()
            return self.group[group_name]

        def GetGroup(self, group_name):
            temp = self.group.get(group_name)
            if temp:
                return temp
            else:
                return self.CreateNewGroup(group_name)

        def AddCollider(self, item):
            self.GetGroup(item.GetGroupName()).add(item)

        def RemoveCollider(self, item):
            self.GetGroup(item.GetGroupName()).remove(item)

    class System_CtrlManage(GameThread):
        def __init__(self, data):
            super().__init__(name="controller_thread", daemon=True)
            self.data = data
            self.key_ctrl = dict()  # key:eve_name values:eve_func
            self.mouse_ctrl = dict()  # 存放实例对象
            self.mousemove_ctrl = dict()  # 存放实例对象
            self._key_ctrl = dict()  # 存放类对象
            self._mouse_ctrl = dict()
            self._mousemove_ctrl = dict()
            self._id = 0

        def CtrlHandler(self, data, eve):
            self.data.SysGetCore().CtrlHandler(data, eve)

        def EnpowerWinCtrl(self, win, _id=0):
            if win.TypeView is not None: return
            self._id = _id
            view_ctrl_id = 0
            for name in win.GetCtrlInfos():
                temp = self.GetKeyController(name)
                if not temp:
                    temp = self.GetMouseController(name)
                    if not temp:
                        temp = self.GetMouseMoveController(name)
                if not temp: continue
                if hasattr(temp, "TypeKey"):
                    self.key_ctrl[self._id] = temp(self.data, win)
                elif hasattr(temp, "TypeMouse"):
                    self.mouse_ctrl[self._id] = temp(self.data, win)
                elif hasattr(temp, "TypeMouseMove"):
                    self.mousemove_ctrl[self._id] = temp(self.data, win)
                else:
                    raise MissingAttributes(name, "'TypeKey'", "'TypeMouse'", "'TypeMouseMove'", "请确保你的类中至少有以上属性的一种")
                win._sys_write_ctrl_id_(view_ctrl_id, self._id)
                view_ctrl_id += 1
                self._id += 1
            for i in win.GetViews():
                self.EnpowerWinCtrl(i, self._id)

        def GetWinKeyCtrl(self):
            return self.key_ctrl.values()

        def GetWinMouseCtrl(self):
            return self.mouse_ctrl.values()

        def GetWinMouseMoveCtrl(self):
            return self.mousemove_ctrl.values()

        def GetAllKeyCtrl(self):
            """
            均为对类对象操作
            """
            return self._key_ctrl.values()

        def GetAllMouseCtrl(self):
            """
            均为对类对象操作
            """
            return self._mouse_ctrl.values()

        def GetAllMouseMoveCtrl(self):
            """
            均为对类对象操作
            """
            return self._mousemove_ctrl.values()

        def GetKeyController(self, name):
            """
            均为对类对象操作
            """
            return self._key_ctrl.get(name)

        def GetMouseController(self, name):
            """
            均为对类对象操作
            """
            return self._mouse_ctrl.get(name)

        def GetMouseMoveController(self, name):
            """
            均为对类对象操作
            """
            return self._mousemove_ctrl.get(name)

        def UpdateKeyCtrl(self, key_ctrl_dict):
            """
            更新类对象储存，即用户定义的类
            """
            self._key_ctrl.update(key_ctrl_dict)

        def UpdateMouseCtrl(self, mouse_ctrl_dict):
            """
            更新类对象储存，即用户定义的类
            """
            self._mouse_ctrl.update(mouse_ctrl_dict)

        def UpdateMouseMoveCtrl(self, mousemove_ctrl_dict):
            """
            更新类对象储存，即用户定义的类
            """
            self._mousemove_ctrl.update(mousemove_ctrl_dict)

        def DeleteCtrl(self, ctrl_id):
            """
            删除指定的实例对象
            """
            self.key_ctrl.pop(ctrl_id, None)
            self.mousemove_ctrl.pop(ctrl_id, None)
            self.mouse_ctrl.pop(ctrl_id, None)

    class System_EveManage(GameThread):
        def __init__(self, data):
            super().__init__(name="event_thread", daemon=True)
            self.data = data
            self.eve_id = 24
            self.eve = dict()  # key:eve_name values:event_id

        def DoPeriodicTask(self, maker, delta_tick, func, task_id, kwargs):
            maker.GetPeriodicTasks()[task_id] = {"_move_tick": delta_tick, "func": func, "kwargs": kwargs}

        def CancelPeriodicTask(self, maker, period_id):
            if maker.GetPeriodicTasks().get(period_id):
                del maker.GetPeriodicTasks()[period_id]

        def EventHandler(self, data, eve):
            self.data.SysGetCore().EventHandler(data, eve)

        def PeriodTaskHandler(self, data):
            self.data.SysGetCore().PeriodTaskHandler(data)

        def GetAllEveId(self):
            return self.eve.values()

        def GetAllEveName(self):
            return self.eve.keys()

        def ListenForEvent(self, maker, event_name, func):
            if not hasattr(maker, "_events"):
                raise (Exception("This inst can't make listen for event."))
            maker.events[self.GetEventId(event_name)] = func  # 对应的view 里储存event_id-->函数信息,由core处理

        def CancelListen(self, maker, event_name):
            del maker.events[self.GetEventId(event_name)]

        def PushEvent(self, maker, event_name, **kwargs):
            id = self.GetEventId(event_name)
            kwargs["maker"] = maker
            event.post(event.Event(id, **kwargs))

        def GetEventId(self, event_name):
            try:
                return self.eve[event_name]
            except:
                return self.AddNewEvent(event_name)

        def AddNewEvent(self, event_name):
            self.eve_id += 1
            self.eve[event_name] = self.eve_id
            return self.eve_id

        def UpdateEve(self, eve_dict):
            self.eve.update(eve_dict)

    class System_ImgManage(GameThread):
        def __init__(self, data):
            super().__init__(name="image_thread", daemon=True)
            self.data = data
            self.img = dict()  # key="name" value=dict([dict("scale","rotate","hflip","vflip","num")],[list(surfaces)])

            #    "name"          , 0~100,0~360,0/1,0/1,number

        def GetAllImgs(self):
            return self.img.values()

        def GetAllImg(self):
            return self.img

        def UpdateImg(self, img_dict):
            self.img.update(img_dict)

        def __tidy__(self, scale, rotate, hflip, vflip):
            if not isinstance(scale, str):
                scale = str(scale)
                if len(scale) <= 2:
                    scale = "0" + scale
                    if len(scale) == 2:
                        scale = "0" + scale
            if not isinstance(rotate, str):
                rotate = str(rotate)
                if len(rotate) <= 2:
                    rotate = "0" + rotate
                    if len(rotate) == 2:
                        rotate = "0" + rotate
            if not isinstance(hflip, str):
                hflip = str(hflip)
            if not isinstance(vflip, str):
                vflip = str(vflip)
            return scale, rotate, hflip, vflip

        def GetImage(self, name, scale="100", rotate="000", hflip="0", vflip="0"):
            scale, rotate, hflip, vflip = self.__tidy__(scale, rotate, hflip, vflip)
            key = scale + rotate + hflip + vflip + name
            if key in self.img:
                return self.img[key]["default"]
            else:
                return self.data.SysGetCore().CreateAndLogFromImage(self.data, name, scale, rotate, hflip,
                                                                    vflip)

    class System_WinManage(GameThread):
        def __init__(self, data):
            super().__init__(name="window_thread", daemon=True)
            self.data = data
            self.win = dict()  # key:win_name # values:window_view object

            self.top_targets = list()
            self.top_layer = -1

            self.target = None

        def UpdateGameWindow(self):
            self.data.screen.fill((10, 10, 10))
            self.data.SysGetWindow().Update()
            display.update()

        def HappenDisabled(self, view):
            if view.layer == self.top_layer and view in self.top_targets:
                self.top_targets.remove(view)
                if not self.top_targets:
                    self.UpdateTopWindow()

        def HappenEnabled(self, view):
            if view.layer > self.top_layer:
                self.top_targets = [view]
                self.top_layer = view.layer
            elif view.layer == self.top_layer:
                self.top_targets += [view]

        def GetTopLayer(self):
            return self.top_layer

        def GetTopTargets(self):
            return self.top_targets

        def UpdateTopWindow(self):
            self.top_layer = -1
            for i in self.GetTarget().GetViews():
                if i.GetStatus():
                    if i.layers > self.top_layer:
                        self.top_targets = [i]
                        self.top_layer = i.layers
                    elif i.layers == self.top_layer:
                        self.top_targets += [i]

        def GetAllWin(self):
            return self.win.values()

        def UpdateWin(self, win_dict):
            self.win.update(win_dict)

        def SetTarget(self, target_name):
            self.target = self.GetWindow(target_name)
            self.data.SysGetCtrlManage().EnpowerWinCtrl(self.target)

        def GetTarget(self):
            return self.target

        def GetWindow(self, name):
            try:
                return self.win[name]
            except:
                raise (Exception(
                    "Can't find window named " + name + "."))

    class System_SoundManage(GameThread):
        def __init__(self, data):
            super().__init__(name="music_thread", daemon=True)
            self.data = data
            self.sound = dict()  # key:sound_name values:sound_obj
            self.music_queue = []
            self.rec = Tick(60)  # 执行检测倒计数
            self.time_srt = time.time()  # 起点时间
            self.time_end = time.time()  # 终点时间
            # self.music = dict()  # music won't be load pre game

        def GetAllSound(self):
            return self.sound.values()

        def GetSound(self, name):
            try:
                return self.sound[name]
            except:
                raise (Exception(
                    "Can't find sound named " + name + "."))

        def SoundEffect(self, name, volume=None):
            """
            播放指定的音效(可以是还没有记录在sound dict里面的音乐)
            param name: 音效文件名或标识符String
            """
            if name not in self.sound.keys():  # 说明是个音乐文件
                path = os.path.join(self.data.st.PATH_SET["sound"], "music", name + ".ogg")
                if os.path.exists(path):
                    self.music_queue.append(pg.mixer.Sound(path))
                else:
                    raise (Exception("Does not find file " + path + " in music."))
            else:
                self.sound[name].play()

        def SoundStop(self):
            """
            终止音乐播放
            注意此种停止音乐播放将不能恢复，会失去所有的播放进度
            """
            pg.mixer.music.stop()

        def SoundPause(self):
            """
            暂停音乐播放
            """
            pg.mixer.music.pause()

        def SoundStart(self):
            """
            再次播放音乐
            """
            pg.mixer.music.unpause()

        def UpdateSound(self, sound_dict):
            self.sound.update(sound_dict)

        def MusicQueueHandler(self):
            """
            一次音乐文件的处理方法，用于检测音乐文件是否播放完毕
            如果没有就使rec--,
            因为队列执行速度有时会变慢，所以后来才用了time的，bug已修复
            """
            if self.rec.tick():
                if len(self.music_queue) and self.time_end <= time.time():
                    self.music_queue[0].play()
                    self.time_srt = time.time()
                    self.time_end = time.time() + self.music_queue[0].get_length()
                    self.music_queue.pop(0)
                # else:
                #     print(self.time_end - time.time())

        def run(self):
            time.sleep(1)
            super(Data.System_SoundManage, self).run()

    class System_Camera:
        def __init__(self, data):
            self.data = data
            self._pos = [0, 0]
            self._height = 100
            self._min_height, self._max_height = 50, 200
            self.delta_pos = [0, 0]
            self.floor_pos = [0, 0]
            self.delta_height = 0
            self._move_tick, self._scale_tick = Tick(0), Tick(0)
            self._move_tick.Disabled()
            self._scale_tick.Disabled()

        def SetHeight(self, height):
            self._height = self._max_height if height > self._max_height else (
                self._min_height if height < self._min_height else height)

        def SetPos(self, pos):
            self._pos = pos

        def GetHeight(self):
            return self._height

        def GetScaleRate(self):
            return 100 / self._height

        def GetPos(self):
            return self._pos

        def Transfer(self, pos):
            return self._pos[0] + pos[0], self._pos[1] + pos[1]

        def LiftCamera(self, _to_height, tick):
            self._scale_tick.Enabled()
            self._scale_tick.SetTim(tick)
            self.delta_height = (_to_height - self._height) / tick

        def MoveCamera(self, desc_pos, tick):
            self._move_tick.Enabled()
            self._move_tick.SetTim(tick)
            self.delta_pos = [(desc_pos[0] - self._pos[0]) / tick, (desc_pos[1] - self._pos[1]) / tick]
            self.floor_pos = self._pos.copy()

        def CameraMoveUpdate(self):
            if self._move_tick.GetStatus():
                if self._move_tick.tick():
                    self._move_tick.Disabled()
                else:
                    self.floor_pos[0] += self.delta_pos[0]
                    self.floor_pos[1] += self.delta_pos[1]
                    self._pos = int(self.floor_pos[0]), int(self.floor_pos[1])

        def CameraScaleUpdate(self):
            if self._scale_tick.GetStatus():
                if self._scale_tick.tick():
                    self._scale_tick.Disabled()
                else:
                    self.SetHeight(self._height + self.delta_height)

        def CameraUpdate(self):
            self.CameraMoveUpdate()
            self.CameraScaleUpdate()

    class System_LogManage(object):
        def __init__(self, data):
            import traceback
            self.tr = traceback.extract_stack
            self.data = data
            self.loggor = logging.getLogger()
            self.loggor.setLevel(logging.DEBUG)
            self.path = None

        def debug(self, msg, **kwargs):
            if self._debug:
                print("debug -> " + msg)
                if not self.__check(): return
                self.loggor.debug(self.__trace() + " -> " + msg, **kwargs)

        def info(self, msg, **kwargs):
            if self._debug:
                print("info -> " + msg)
            if not self.__check(): return
            self.loggor.info(self.__trace() + " -> " + msg, **kwargs)

        def warn(self, msg, **kwargs):
            if self._debug:
                print("warning -> " + msg)
            if not self.__check(): return
            self.loggor.warning(self.__trace() + " -> " + msg, **kwargs)

        def error(self, msg, **kwargs):
            if self._debug:
                print("error -: " + msg)
            if not self.__check(): return
            self.loggor.error(self.__trace() + " -: " + msg, **kwargs, exc_info=True)

        def critic(self, msg, **kwargs):
            if self._debug:
                print("critical !: " + msg)
            if not self.__check(): return
            self.loggor.critical(self.__trace() + " !: " + msg, **kwargs)

        def __trace(self):
            tr = self.tr()[-4]  # -1 is __trace, -2 is info(debug, ...), -3 is caller, -4 is support
            p = os.path.join(os.path.basename(os.path.dirname(tr[0])), os.path.basename(tr[0]))
            return "{}[line:{}]: {}".format(p, tr[1], tr[2])

        def __check(self):
            if not self.path:
                print("Warning: Logger is disabled.")
                return False
            if not self._logable:
                return False
            return True

        """
        你不能删除一些日志的内容
        """

        def Active(self):
            self.path = self.data.st.LOGPATH
            self._logable = self.data.st.LOG_MODE
            self._debug = self.data.st.DEBUG_MODE
            if not self.path:
                print("Unable To Start Logger, It Will Be Disabled.")
                return
            self.fn = logging.FileHandler(os.path.join(self.path, "Game.log"), mode='w')
            self.fn.setLevel(logging.DEBUG)

            ft = logging.Formatter(LOG_FORMATTER)
            ft.default_time_format = '%H:%M:%S'
            ft.default_msec_format = "%s.%.3d"
            self.fn.setFormatter(ft)
            self.loggor.addHandler(self.fn)

            self.info("PgFrame Version: " + package_version)
            self.info("Logger is Actived at " + time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))
            if not self._logable:
                self.info("for user setting, log is disable.")

    def __init__(self):
        self.system_support_part_img_manage = self.System_ImgManage(self)
        self.system_support_part_eve_manage = self.System_EveManage(self)
        self.system_support_part_win_manage = self.System_WinManage(self)
        self.system_support_part_ctrl_manage = self.System_CtrlManage(self)
        self.system_support_part_group_manage = self.System_GroupManage(self)
        self.system_support_part_sound_manage = self.System_SoundManage(self)
        self.system_support_part_camera = self.System_Camera(self)
        self.log = self.System_LogManage(self)
        self.system_support_part_target_win = None
        self.system_support_part_tick = 0

    """
    使用.syslog直接管理LogManage
    """

    def SysGetTick(self):
        return self.system_support_part_tick

    def System_SetTick(self, tick):
        self.system_support_part_tick = tick

    def System_TickIadd(self):
        self.system_support_part_tick += 1

    def System_TickSetProcess(self):
        self.System_TickIadd()
        if self.SysGetTick() >= 65536 - 1:
            self.System_SetTick(0)

    def System_GetThingsReady(self, srt_window):
        if not self.game___init__:
            raise (Exception("you need init first."))
        for i in self.BaseInfo:
            if not hasattr(self, i):
                raise (Exception(
                    "pgframe need init first.So check whether your parameters are full or not."))
        self.core = GetCore()
        self.System_LoadCtrl()
        self.System_LoadImg()
        self.System_LoadEve()
        self.System_LoadWin()
        self.System_LoadSound()
        self.SysGetWinManage().SetTarget(srt_window)
        self.system_support_part_target_win = self.SysGetWinManage().GetTarget()

        UpdateModelData(self)

    def System_LoadSound(self):
        pg.mixer.init(frequency=self.st.AUDIO_BIT, buffer=self.st.AUDIO_BUFFER)
        self.system_support_part_sound_manage.start()
        self.SysGetSoundManage().SetTick(self.st.FREQUENCY)
        self.log.info("-- Load Sounds:")
        self.SysGetCore().ImportSounds(self, os.path.join(self.st.PATH_SET["sound"], "sound"))
        self.log.info("-- Successfully Load Sounds --" + LOG_SEPARATE)  # sound 是最后一个加载的
        self.SysGetSoundManage().Ready()

    def System_LoadCtrl(self):
        self.system_support_part_ctrl_manage.start()
        self.SysGetCtrlManage().SetTick(self.st.FREQUENCY)
        self.log.info("-- Load Controllers:")
        self.SysGetCore().ImportCtrls(self)
        self.log.info("-- Successfully Load Controllers --\n")
        self.SysGetCtrlManage().Ready()

    def System_LoadEve(self):
        self.system_support_part_eve_manage.start()
        self.SysGetEveManage().SetTick(self.st.FREQUENCY)
        for i in self.ev.LogEveLoading():
            self.SysGetEveManage().AddNewEvent(i)
        self.SysGetEveManage().Ready()

    def System_LoadImg(self):
        self.system_support_part_img_manage.start()
        self.SysGetImgManage().SetTick(self.st.FREQUENCY)
        self.log.info("-- Load Images:")  # special
        self.SysGetCore().ImportImgs(self, self.st.PATH_SET["img"])
        self.log.info("-- Successfully Load Images --\n")  # special
        self.SysGetSoundManage().Ready()

    def System_LoadWin(self):
        self.system_support_part_win_manage.start()
        self.SysGetWinManage().SetTick(self.st.FREQUENCY)
        self.log.info("-- Load Views:")
        self.SysGetCore().ImportWins(self)
        self.log.info("-- Successfully Load Views --\n")
        self.SysGetWinManage().Ready()

    def System_DoPeriodicTask(self, maker, delta_time, func, **kwargs):
        delta_tick = (delta_time * self.st.FREQUENCY) // 1
        self.SysGetEveManage().AddQueue("DoPeriodicTask", maker=maker, delta_tick=delta_tick, func=func,
                                        task_id=maker.task_id, kwargs=kwargs)
        maker.task_id += 1
        return maker.task_id - 1

    def System_CancelPeriodicTask(self, maker, period_id):
        self.SysGetEveManage().AddQueue("CancelPeriodicTask", maker=maker, period_id=period_id)

    def SysGetWindow(self):
        """
        获取当前根视图
        Get the current root view
        :return: object --> 实例化视图对象 Instantiate View Object
        """
        return self.system_support_part_target_win

    def SysGetCore(self):
        """
        获取核心对象
        Get Core Objects
        :return: object --> 核心对象 Core Objects
        """
        return self.core

    def SysGetAllWin(self):
        """
        获取当前已注册的所有视图
        Get all currently registered _views
        :return: list --> 视图列表 _views list
        """
        return self.system_support_part_win_manage.GetAllWin()

    def SysGetAllImg(self):
        """
        获取当前已注册的所有图片
        Get all currently registered p_images
        :return: list --> 图片列表 p_images list
        """
        return self.system_support_part_img_manage.GetAllImg()

    def SysGetAllEve(self):
        """
        获取当前已注册的所有事件
        Get all currently registered _events
        :return: list --> 事件列表 _events list
        """
        return self.system_support_part_eve_manage.GetAllEveName()

    def SysGetAllEveId(self):
        """
        获取当前已注册的所有事件id
        Get all currently registered _events' id
        :return: list --> 事件id列表 _events' id list
        """
        return self.system_support_part_eve_manage.GetAllEveId()

    def SysGetImgManage(self):
        """
        获取图片管理器
        Get Image Manager
        :return: object --> 图片管理器 Image Manager
        """
        return self.system_support_part_img_manage

    def SysGetEveManage(self):
        """
        获取事件管理器
        Get Event Manager
        :return: object --> 事件管理器 Event Manager
        """
        return self.system_support_part_eve_manage

    def SysGetWinManage(self):
        """
        获取视图管理器
        Get View Manager
        :return: object --> 视图管理器 View Manager
        """
        return self.system_support_part_win_manage

    def SysGetCtrlManage(self):
        """
        获取控制管理器
        Get Controller Manager
        :return: object --> 控制管理器 Controller Manager
        """
        return self.system_support_part_ctrl_manage

    def SysGetGroupManage(self):
        """
        获取分组管理器
        Get Group Manager
        :return: object --> 分组管理器 Group Manager
        """
        return self.system_support_part_group_manage

    def SysGetCamera(self):
        """
        获取相机
        Get Camera
        :return: object --> 相机 Camera
        """
        return self.system_support_part_camera

    def SysMoveCamera(self, aim_pos, tick):
        """
        移动相机
        :param aim_pos: tuple(int,int) 目标点
        :param tick: int 间隔帧
        :return: None
        """
        self.SysGetCamera().MoveCamera(aim_pos, tick)

    def SysGetSoundManage(self):
        """
        获取声音管理器
        Get Sound Manager
        :return: object --> 声音管理器 Sound Manager
        """
        return self.system_support_part_sound_manage

    def SysGetScreen(self):
        """
        获取显示屏幕
        Get Display Screen
        :return: object --> 显示区域的屏幕 Display Screen
        """
        return self.screen
