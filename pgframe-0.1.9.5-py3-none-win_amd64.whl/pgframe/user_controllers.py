# 这是一个用户文件
from pgframe.controllers import *


class Test(KeyCtrl):
    def Loading(self, **kwargs):
        self.SetKey("SPACE")
        self.SetFunc(self.Test)

    def Test(self, eve, **kwargs):
        self.inst.CancelController(self.inst.t_id)
        print("ctrl 已移除")


class Up(KeyCtrl):
    def Loading(self, **kwargs):
        self.SetKey("UP")
        self.SetFunc(self.fn)

    def fn(self, eve, **kwargs):
        if eve.status:
            self.inst.motor.Move("up", 0, -5)
        else:
            self.inst.motor.Stop("up")


class Down(KeyCtrl):
    def Loading(self, **kwargs):
        self.SetKey("DOWN")
        self.SetFunc(self.fn)

    def fn(self, eve, **kwargs):
        if eve.status:
            self.inst.motor.Move("down", 0, 5)
        else:
            self.inst.motor.Stop("down")

class Left(KeyCtrl):
    def Loading(self, **kwargs):
        self.SetKey("LEFT")
        self.SetFunc(self.fn)

    def fn(self, eve, **kwargs):
        if eve.status:
            self.inst.motor.Move("left", -5, 0)
        else:
            self.inst.motor.Stop("left")

class Right(KeyCtrl):
    def Loading(self, **kwargs):
        self.SetKey("RIGHT")
        self.SetFunc(self.fn)

    def fn(self, eve, **kwargs):
        if eve.status:
            self.inst.motor.Move("right", 5, 0)
        else:
            self.inst.motor.Stop("right")