# 这是一个用户文件
import os

# 基础路径设置
PATH = os.path.dirname(__file__)
if not os.path.exists(os.path.join(PATH, "main.py")):
    PATH = os.getcwd()
LOGPATH = os.path.join(PATH, "log")
DATAPATH = os.path.join(PATH, "data")
PATH_SET = dict(img=os.path.join(DATAPATH, "img"), sound=os.path.join(DATAPATH, "sound"), datum=os.path.join(DATAPATH, "datum"))
SOURCES = [
    # paths in root_path which want to be automatically exported
]

# 主要设置:
TITLE_CAPTION = "PgFrameExample"
TITLE_ICON = "game.png"
DEFAULT_WINDOW_SIZE = (600, 800)
FREQUENCY = 60
LOG_MODE = True  # it would cost some secs when starting program
DEBUG_MODE = False  # it would cost extra series secs while starting program, and it must enabled after LOG_MODE is True

# 高级设置:
AUTO_UPDATE_MODEL = False  # 请在需要的时候激活一次，激活时启动会显著消耗更多资源

AUTO_TIDY = dict()
AUDIO_BIT = 44100
AUDIO_BUFFER = 512

Window_Center_Adjust = (0, 38)
