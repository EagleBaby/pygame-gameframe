# 这是一个用户文件
from pgframe.views import View
from models import *


class Root(View):
    auto = True
    layer = -1

    def Loading(self, **kwargs):
        self.AddView(Main)


class Main(View):
    def Loading(self, **kwargs):
        ...
