from warnings import warn

import numpy as np


def d_pos(x, y):
    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _pos=(x, y))

        return Inner_Wrapper

    return Wrapper


def d_percent(percent_x, percent_y):
    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _percent=(percent_x, percent_y))

        return Inner_Wrapper

    return Wrapper


def d_size(width, height):
    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _size=(width, height))

        return Inner_Wrapper

    return Wrapper


def d_layer(layer):
    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _layer=layer)

        return Inner_Wrapper

    return Wrapper


def d_show(isShow=True):
    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _show=isShow)

        return Inner_Wrapper

    return Wrapper


def d_view(param):
    """
    添加view(只能对同类对象使用)
    :param param: [[class_View, kwargs], ......]
    :return: None
    """

    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _views=param)

        return Inner_Wrapper

    return Wrapper


def d_cp(param):
    """
    添加components
    :param param: [[component_name, kwargs], ......]
    :return: None
    """

    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _components=param)

        return Inner_Wrapper

    return Wrapper


def d_ct(param):
    """
    添加controllers
    :param param: [controllers_name, ......]
    :return: None
    """

    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _components=param)

        return Inner_Wrapper

    return Wrapper


def _anim(param):
    """
    添加anim(只能对同类对象使用)
    :param param: [[class_Anim, kwargs], ......]
    :return: None
    """

    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _anims=param)

        return Inner_Wrapper

    return Wrapper


def d_spirit(param):
    """
    添加spirit
    :param param: [[ArtDef, kwargs], ......]
    :return: None
    """

    def Wrapper(_view_type_cls):
        def Inner_Wrapper(*args, **kwargs):
            return _view_type_cls(*args, **kwargs, _spirits=param)

        return Inner_Wrapper

    return Wrapper


class BaseView(object):
    auto = False

    def __init__(self, data, inst=None, view_id=None, show=True, **kwargs):
        self.inst = inst
        self.data = data
        self.TypeView = None

        self.layer = 0
        if kwargs.get("_layer"):
            self.layer = kwargs["_layer"]

        self.pos = None
        if kwargs.get("_pos"):
            self.pos = kwargs["_pos"]

        self.perpos = (0, 0)
        if kwargs.get("_percent"):
            self.perpos = kwargs["_percent"]

        self.size = data.st.DEFAULT_WINDOW_SIZE
        if kwargs.get("_size"):
            self.size = kwargs["_size"]

        self._show = show
        if kwargs.get("_show"):
            self._show = kwargs["_show"]

        self._wait = []  # [(code_list, per_tick)]
        self._camera_last_pos = data.SysGetCamera().GetPos()
        self._camera_scale = data.SysGetCamera().GetScaleRate()
        self._views = dict()
        self._events = dict()
        self._components = dict()
        self._self_id = view_id
        self.task_id = 0
        self._vw_id = 0
        self._cp_id = 0
        self._queue = []
        self.tag = list()

    def _get_eve_(self):
        return self._events

    events = property(_get_eve_)

    def GetLayer(self):
        """
        获得view所处的层级
        :return:
        """
        return self.layer

    def GetId(self):
        """
        获取view id
        :return: int view id
        """
        return self._self_id

    def PlaySound(self, name, volume=100):
        """
        播放声音和音乐，如果音乐和音乐处于播放状态，则将在音乐播放完毕后播放。
        Play sound and music,if music and music is on play then will play after music now finish play.
        :param name: string --> filename without .xxx
        :param volume: int --> if it is possible，it will affect sound' s volume.
        :return: None
        """
        self.data.SysGetSoundManage().AddQueue("SoundEffect", name=name, volume=volume)

    def StopSound(self):
        """
        停止音乐（声音无法停止），将丢失所有等待的音乐。
        Stop music(sound can not be stopped), will lost all waited music.
        :return: None
        """
        self.data.SysGetSoundManage().AddQueue("SoundStop")

    def PauseSound(self):
        """
        暂停音乐（声音不能暂停），不会丢失等待的音乐。
        Pause music(sound can not be paused), will not lost waited music.
        :return: None
        """
        self.data.SysGetSoundManage().AddQueue("SoundPause")

    def StartSound(self):
        """
        开始暂停的音乐（无法启动声音）
        Start paused music(sound can not be started)
        :return: None
        """
        self.data.SysGetSoundManage().AddQueue("SoundStart")

    def GetCenterPos(self, absolute=False):
        """
        获取视图的中心位置
        Get view' s center position
        :param absolute: Bool True-->绝对参考系;False-->相机参考系,默认True
        :return: position tuple(int/float left, int/float top)
        """
        pos = self.GetPos()
        return int(pos[0] + self.size[0] * .5), int(pos[1] + self.size[1] * .5)

    def GetCenterPerPos(self):
        """
        获取当前视图中心点在父视图的相对位置百分比
        Gets the relative position percentage of the current view center point in the parent view
        :return: percent tuple(float --> per_X,float --> per_Y)
        """
        if self.inst:
            size = self.inst.GetSize()
            pos = self.inst.GetPos()
            return (self.pos[0] - pos[0] + self.size[0] * .5) / size[0], (self.pos[1] - pos[1] + self.size[1] * .5) / \
                   size[1]
        else:
            return (self.data.SysGetScreen().get_width() * self.perpos[0] + self.size[
                0] * .5) / self.data.SysGetScreen().get_width(), \
                   (self.data.SysGetScreen().get_height() * self.perpos[0] + self.size[
                       1] * .5) / self.data.SysGetScreen().get_height()

    def GetPercent(self, axis=None):
        """
        获取当前视图位置在父视图中的相对位置百分比(这个百分比只与自身与父窗口有关，与相机位置无关)
        Gets the relative position percentage of the current view position in the parent view
        :param axis: 0/1 表示仅返回横向百分比或仅返回纵向百分比 Indicates that only horizontal percentage or vertical percentage is returned
        :return: percent tuple(float --> per_X,float --> per_Y) or float --> per_X or float --> per_Y
        """
        if self.pos:
            if self.inst:
                size = self.inst.GetSize()
                pos = self.inst.GetPos()
                temp = (self.pos[0] - pos[0]) / size[0], (self.pos[1] - pos[1]) / size[1]
            else:
                temp = (self.data.SysGetScreen().get_width() * self.perpos[
                    0]) / self.data.SysGetScreen().get_width(), \
                       (self.data.SysGetScreen().get_height() * self.perpos[
                           0]) / self.data.SysGetScreen().get_height()
        else:
            temp = self.perpos
        if axis is not None:
            return temp[axis]
        return temp

    def SetPercent(self, percent, reset=False):
        """
        设置当前视图在父视图中的百分比
        Sets the percentage of the current view in the parent view
        :param percent: float --> 当前视图在父视图中的百分比 The percentage of the current view in the parent view
        :param reset: bool --> 是否运用到当前视图的当前位置(即立刻改变位置到指定百分比) Whether to apply to the current position of the current view (i.e. immediately change the position to a specified percentage)
        :return: None
        """
        self.perpos = percent
        if reset:
            self.ResetPos()

    def GetPos(self, absolute=False):
        """
        获得当前视图在绝对参考系中或相机参考系中的位置
        Get the location of the current view
        :param absolute: Bool True-->绝对参考系;False-->相机参考系,默认True
        :return: position tuple(int/float --> x,int/float --> y)
        """
        if absolute or not self.pos:
            return self.pos
        else:
            a, b = self.data.SysGetCamera().GetPos()
            return self.pos[0] - a, self.pos[1] - b

    def __GetPosition(self):
        return self.inst.pos[0] + self.inst.size[0] * self.perpos[0], self.inst.pos[1] + self.inst.size[1] * \
               self.perpos[1]

    def SetPos(self, pos):
        """
        设置当前视图在绝对参考系的位置
        Set the location of the current view
        :param pos: tuple(int/float --> x,int/float --> y)
        :return: None
        """
        self.pos = pos

    def SetCenterPos(self, pos):
        """
        设置当前视图的中心位置
        Set the center location of the current view
        :param pos: tuple(int/float --> x,int/float --> y)
        :return: None
        """

        self.SetPos((pos[0] - int(self.size[0] * .5), pos[1] - int(self.size[1] * .5)))

    def ResetPos(self):
        """
        重置位置为当前视图在父视图中的相对百分比处的位置
        Resets the position to the relative percentage of the current view in the parent view
        :return: None
        """
        self.pos = None

    def GetSize(self):
        """
        获取当前视图的尺寸
        Get the size of the current view
        :return: size tuple(int/float --> width,int/float --> height)
        """
        if self.auto:
            return self.data.st.DEFAULT_WINDOW_SIZE
        return self.size

    def SetSize(self, size):
        """
        设置视图的大小(根视图无法调整大小，若需调整根视图大小，请在设置中调整)
        Set the size of the current view
        :param size: size tuple(int/float --> width,int/float --> height)
        :return: None
        """
        if self.auto:
            raise (Exception("Root View can not SetPos. If you want, please set in settings."))
        self.size = size

    def Hide(self):
        """
        隐藏视图，原先处于显示状态下的视图内绑定的所有对象都会停止工作(原先处于隐藏状态下的视图不受影响)
        Hide the view. All objects bound in the view in the original display state will stop working (the view in the original hidden state will not be affected)
        :return: None
        """
        if self._show:
            self._show = False
            self.data.SysGetWinManage().AddQueue("HappenDisabled", view=self)

    def Show(self):
        """
        显示视图，原先处于隐藏状态下的视图内绑定的所有对象都会开始工作(原先处于显示状态下的视图不受影响)
        Display view, all objects bound in the view in the previously hidden state will start to work (the view in the previously displayed state will not be affected)
        :return: None
        """
        if not self._show:
            self._show = True
            self.data.SysGetWinManage().AddQueue("HappenEnabled", view=self)

    def GetStatus(self):
        """
        获取当前视图是否可见
        Get whether the current view is visible
        :return: bool--> 可见:True;不可见:False
        """
        return self._show


class View(BaseView):
    """
    mcv中的v部分，显示在屏幕上
    可绑定组件和控制器(c)

    """

    def __init__(self, data, inst=None, __system_calling_trig__=False, view_id=None, **kwargs):
        super().__init__(data, inst, view_id, **kwargs)

        for i in kwargs.get("-views", []):
            self.AddView(i[0], **i[1])

        for i in kwargs.get("_components", []):
            self.AddComponent(i[0], **i[1])

        for i in kwargs.get("-controllers", []):
            self.LogController(i)

        self._ctrl_name = dict()
        self._ctrl_sys_id_ = dict()  # 这个是ctrl manager 回调id储存器，数据是实例化ctrl的id
        self._ct_id = 0
        self._task_id = 0
        self._events = dict()  # event_id --> event_func
        self._periods = dict()  # period_id --> [dt,task_func,kwargs]
        self._kwargs = kwargs
        self.__system_calling_trig__ = __system_calling_trig__
        if not __system_calling_trig__:
            self.Loading(**kwargs)
            self.data.SysGetWinManage().AddQueue("HappenEnabled", view=self)
            if self.inst and self.size == data.st.DEFAULT_WINDOW_SIZE:
                warn(Warning(self.__class__.__name__ + "doesn' t set size, it will use the default size in setting."))

    def system_redo(self):
        """
        系统调用，用户调用可能导致bug
        :return: None
        """
        if self.auto and self.__system_calling_trig__:
            self.Loading(**self._kwargs)
            if self.inst and self.size == self.data.st.DEFAULT_WINDOW_SIZE:
                warn(Warning(self.__class__.__name__ + "doesn' t set size, it will use the default size in setting."))

    def __call__(self, *args, **kwargs):
        pass

    def GetListenTask(self, event_id):
        """
        按唯一id获取侦听任务（由用户发出）
        Get listen task by unique id(by user)
        :param event_id: int --> event id
        :return: function --> event function
        """
        return self._events.get(event_id)

    def GetListenTasks(self):
        """
        获取所有侦听任务（由用户发出）
        Get listen tasks(by user)
        :return: function list --> event functions list
        """
        return self._events

    def GetPeriodicTask(self, period_id):
        """
        获取周期事件的函数
        Get function of periodic event
        :param period_id: int --> 周期事件的id
        :return: function --> 周期事件的函数
        """
        return self._periods.get(period_id)

    def GetPeriodicTasks(self):
        """
        获取所有周期事件的函数
        Get all functions of periodic event
        :return: function list --> 周期事件的函数列表
        """
        return self._periods

    def Loading(self, **kwargs):
        """
        用户在这里写自己的额外的初始化代码
        Users write their own additional initialization code here
        :param kwargs: **dict --> 自动传递__init__中的kwargs
        :return: None 
        """
        pass

    def AddView(self, view, sign=None, **kwargs):
        """
        为当前视图添加一个子视图
        Add a subview to the current view
        :param view: class --> 子视图的类对象 Class object for subview
        :param sign: String 设置子视图在此视图中的变量名称,None表示不添加
        :param kwargs: **dict --> 子视图的类对象的参数键值对 Parameter Key-Value Pairs of Class Objects in Subview
        :return: int --> 子视图的id ID of subview
        """
        self.data.log.debug("view " + view.__name__ + " is be added by " + self.__class__.__name__)
        if not kwargs.get("inst"):
            kwargs["inst"] = self
        temp = view(self.data, view_id=self._vw_id, **kwargs)
        if not hasattr(temp, "TypeView"):
            raise (TypeError(str(type(view)) + "is not a BaseView object."))
        self._views[self._vw_id] = temp
        if sign:
            setattr(self, sign, self._views[self._vw_id])
        self._vw_id += 1
        return self._vw_id - 1

    def RemoveView(self, view_id):
        """
        移除指定的子视图
        Remove the specified subview
        :param view_id: int --> 子视图的id ID of subview
        :return: None
        """
        v = self._views.get(view_id, None)
        if v: self.data.SysGetWinManage().AddQueue("HappenDisabled", view=v)
        self._views.pop(view_id, None)

    def GetView(self, view_id):
        """
        获取指定的子视图
        Gets the specified subview
        :param view_id: int --> 子视图的id ID of subview
        :return: object --> 子视图的实例化对象 Instantiated objects for subviews
        """
        return self._views[view_id]

    def GetViews(self):
        """
        获取所有的子视图
        Get all subviews
        :return: list --> 子视图实例化对象列表 Subview Instantiate Object List
        """
        return self._views.values()

    def LogController(self, controller_name):
        """
        为当前视图注册控制器,视图完成加载后将不再接收此函数
        Register Controller for Current View
        :param controller_name: string --> 控制器的类名 Class name of the controller
        :return: int --> 控制器id Controller ID
        """
        self._ctrl_name[self._ct_id] = controller_name
        self._ct_id += 1
        return self._ct_id - 1

    def CancelController(self, controller_id):
        """
        取消当前视图的一个已注册的控制器,视图完成加载后将不再接收此函数
        Cancel a registered controller for the current view
        :param controller_id: int --> 控制器的id ID of controller
        :return: None
        """
        self._ctrl_name.pop(controller_id, None)
        instance_id = self._ctrl_sys_id_.pop(controller_id, None)
        if instance_id is not None: self.data.SysGetCtrlManage().AddQueue('DeleteCtrl', instance_id)

    def GetCtrlInfos(self):
        """
        获取所有当前视图的已注册的控制器的注册时的名称信息
        Gets the name information at the time of registration for all registered controllers of the current view
        :return: list --> 控制器的名称信息列表 List of Controller Name Information
        """
        return self._ctrl_name.values()

    def GetCtrlInfo(self, controller_id):
        """
        获取当前视图内指定的已注册的控制器的注册时的名称信息
        Gets the name information for the registered controller specified in the current view at the time of registration
        :param controller_id: int --> 控制器id ID of controller
        :return: string --> 控制器的名称信息 Controller name information
        """
        return self._ctrl_name.get(controller_id)

    def _sys_write_ctrl_id_(self, _view_ctrl_id, _sys_ctrl_id):
        """
        系统调用，用于保存ctrl manager实例化时的ctrl id
        """
        self._ctrl_sys_id_[_view_ctrl_id] = _sys_ctrl_id

    def AddComponent(self, component_name, **kwargs):
        """
        为当前视图添加组件
        Add Components for Current View
        :param component_name: string --> 组件的类名 The class name of the component
        :param kwargs: **dict --> 组件实例化所需的参数的键值对 Key-value pairs of parameters required for component instantiation
        :return: int --> 组件的id ID of component
        """
        self._components[self._cp_id] = getattr(self.data.cp, component_name)(self, **kwargs)
        self._cp_id += 1
        return self._cp_id - 1

    def GetComponents(self):
        """
        获取所有的组件
        Get all _components
        :return: list --> 实例化组件列表 List of instantiated _components
        """
        return self._components.values()

    def GetComponent(self, component_id):
        """
        获取指定的组件
        Gets the specified component
        :param component_id: int --> 组件的id ID of component
        :return: object --> 实例化组件 instantiated component
        """
        return self._components.get(component_id)

    def RemoveComponent(self, component_id):
        """
        移除指定的组件
        Remove the specified component
        :param component_id: int --> 组件的id ID of component
        :return: None
        """
        self._components[component_id].remove()
        self._components.pop(component_id)

    def AddQueue(self, func, **kwargs):
        """
        添加队列任务,但是你无法获得返回值
        :param func: String/Func 函数名/函数
        :param kwargs: **dict参数键值对
        :return: None
        """
        self._queue.append((func, kwargs))

    def Update(self):
        """
        更新视图
        Update the current view.
        :return: None
        """
        if self._queue:
            for i in self._queue:
                if isinstance(i[0], str):
                    getattr(self, i[0])(**i[1])
                else:
                    i[0](**i[1])
            self._queue = []

        self.data.SysGetCore().GetViewAtPosition(self.data, self)
        self.data.SysGetCore().UpdateView(self.data, self)

    def PushEvent(self, event_name, **kwargs):  # id must > 24
        """
        通过根视图触发指定事件
        Trigger the specified event through the root view
        :param event_name: string --> 事件名称 Event Name
        :param kwargs: **dict --> 事件的参数键值对 Parameter key-value pairs for _events
        :return: None
        """
        if self.inst is not None:
            self.inst.PushEvent(event_name, **kwargs)
        else:
            self.data.SysGetEveManage().PushEvent(self, event_name, **kwargs)

    def ListenForEvent(self, event_name, func):
        """
        通过根视图监听指定事件
        Listen for specified _events through root view
        :param event_name: string --> 事件名称 Event Name
        :param func: function(eve,data) --> 事件处理函数 Event Handler
        :return: None
        """
        if self.inst is not None:
            self.inst.ListenForEvent(event_name, func)
        else:
            self.data.SysGetEveManage().ListenForEvent(self, event_name, func)

    def DoPeriodicTask(self, delta_time, func, **kwargs):
        """
        对根视图添加周期任务
        Add cycle task to root view
        :param delta_time: int/float --> 周期任务的周期时间 Cycle time for periodic tasks
        :param func: function(**kwargs) --> 执行函数 Function to be executed
        :param kwargs: **dict --> 执行函数的其他参数的键值对 Key-value pairs for other parameters of the execution function
        :return: int --> 周期任务id ID of Cycle Task
        """
        if self.inst is not None:
            return self.inst.DoPeriodicTask(delta_time, func, **kwargs)
        else:
            return self.data.System_DoPeriodicTask(self, delta_time, func, **kwargs)

    def CancelListen(self, event_name):
        """
        取消根视图对指定事件的监听
        Cancel root view listening to specified _events
        :param event_name: string --> 事件名称 Event Name
        :return: None
        """
        if self.inst is not None:
            return self.inst.CancelListen(event_name)
        else:
            self.data.SysGetEveManage().CancelListen(self, event_name)

    def CancelPeriod(self, period_id):
        """
        取消根视图指定的周期任务
        Cancel cycle task specified by root view
        :param period_id: int --> 周期事件id ID of Cycle Task
        :return: None
        """
        if self.inst is not None:
            self.inst.CancelPeriod(period_id)
        else:
            self.data.System_CancelPeriodicTask(self, period_id)

    def MapInit(self, shape, view, area=(0., 0., 1., 1.), between=(0, 0), filter=None, **kwargs):
        """
        为视图创建一个views map, 其中，子视图可以通过.loc获取他们自身的位置
        :param shape: tuple(int,int) map的形状
        :param view: View 填充的视图,额外传递矩阵信息x，y(0,0<=x,y<=shape[0],shape[1]),额外设置属性map_pos(x,y)
        :param area: tuple(left:float，top:float，width:float，height:float) map区域
        :param between: tuple(int,int) 区块间隔
        :param filter: map(Bools...) 选择性填充
        :param kwargs: **dict View的参数
        :return: 2d-array --> Views   返回 _views map
        """
        self.data.log.debug("view " + self.__class__.__name__ + " is be map inited as " + str(shape) + " by " + view.__class__.__name__)
        if self.auto == False and self.size == self.data.st.DEFAULT_WINDOW_SIZE:
            self.data.log.warn("-->Warning: In " + self.__class__.__name__ + ", you create the map without .SetSize()")
        if self.auto == False:
            if self.pos is None:
                self.data.log.warn("-->Warning: In " + self.__class__.__name__ + ", you create the map without .SetPos()")
                self.SetPos((0, 0))
                trig = True
        else:
            self.SetPos((0, 0))
        if self.auto == False and self.perpos != (0, 0):
            self.data.log.warn(
                "-->Warning: In " + self.__class__.__name__ + ", if you want to create a map, the .SetPerpos() will lose it's effect on your map.")
        size = self.GetSize()
        srt = self.GetPos()[0] + int(area[0] * size[0]), self.GetPos()[1] + int(size[1] * area[1])
        end = self.GetPos()[0] + int(area[2] * size[0]), self.GetPos()[1] + int(size[1] * area[3])
        size = [end[0] - srt[0], end[1] - srt[1]]
        size[0], size[1] = (size[0] - (shape[0] - 1) * between[0]) // shape[0], (
                size[1] - (shape[1] - 1) * between[1]) // shape[1]
        self.view_map = []
        self.map = []
        for i in range(shape[0]):
            for j in range(shape[1]):
                if filter is None or filter[i, j]:
                    self.map.append(self.AddView(view, x=i, y=j, **kwargs))
                    self.view_map.append(self.GetView(self.map[-1]))
                    self.view_map[-1].SetSize(size)
                    self.view_map[-1].SetPos(
                        (srt[0] + size[0] * i + between[0] * (i - 1), srt[1] + size[1] * j + between[1] * (j - 1)))
                    self.view_map[-1].loc = (i, j)
                else:
                    self.view_map.append(None)
                    self.map.append(None)
        self.map = np.array(self.map).reshape(shape)
        self.view_map = np.array(self.view_map).reshape(shape)

        try:
            a = trig
            self.SetPos(None)
        except:
            pass

        return self.view_map

    def __getitem__(self, item):
        x, y = item
        if hasattr(self, "view_map"):
            return self.view_map[x, y]
        else:
            raise (TypeError("'" + self.__class__.__name__ + "' object is not subscriptable"))

    def __delitem__(self, item):
        x, y = item
        if hasattr(self, "view_map"):
            self.RemoveView(self.map[x, y])
            self.map[x, y] = None
            self.view_map[x, y] = None
        else:
            raise (TypeError("'" + self.__class__.__name__ + "' object is not subscriptable"))


class Label(View):
    """
    kwargs:
        left:int = 0, top:int = 0, width:int = 60, height:int = 20

        font:tuple = (None, 30)
        fg:(r, g, b) = (255, 255, 255)
        bold:bool = False
        italic:bool = False

        pic:str = ""  # picture, through .pic
        p_just:(dx, dy) = (0, 0)
        scale:int = 100

        text:str = ""  # text, through .text
        t_just:(dx, dy) = (0, 0)

        focus:str = ""  # controller name, ctrl type must be 'focus'
        cover:str = ""  # extra pic when focus, , through .cover
        c_scale:int = 100
        c_just:(dx, dy) = (0, 0)

    """

    def Loading(self, **kwargs):
        l, t, w, h = kwargs.get('left', 0), kwargs.get('top', 0), kwargs.get('width', 60), kwargs.get('height', 20)
        text, pic = kwargs.get('text', ''), kwargs.get('pic', '')
        font, font_size = kwargs.get('font', (None, 30))
        font_color = kwargs.get('fg', (255, 255, 255))
        font_bold, font_italic = kwargs.get('bold', False), kwargs.get('italic', False)
        pic_size = str(kwargs.get('scale', 100))

        pic_justify, text_justify = kwargs.get('p_just', (0, 0)), kwargs.get('t_just', (0, 0))

        focus = kwargs.get('focus', '')
        cover = kwargs.get('cover', '')
        cover_size, cover_justify = kwargs.get('c_scale', '100'), kwargs.get('c_just', (0, 0))

        self.SetPos((l, t))
        self.SetSize((w, h))
        if pic != '':
            self.AddComponent('Pic', ArtDef=pic, scale=pic_size, justify=pic_justify, sign='pic')
        if cover != '':
            self.AddComponent('Pic', ArtDef=cover, scale=cover_size, justify=cover_justify, sign='cover',
                              show=False)  # cover默认隐藏
        if text != '':
            self.AddComponent('Text', text=text, size=font_size, font=font, color=font_color, show=True,
                              italic=font_bold, bold=font_italic, justify=text_justify, sign='text')
        if focus != '':
            self.LogController(focus)


class Button(Label):
    """
    kwargs:
        ctrl:str  # controller name, ctrl type can user modifier, !!!do not have default!!!

        left:int = 0, top:int = 0, width:int = 60, height:int = 20

        font:tuple = (None, 30)
        fg:(r, g, b) = (255, 255, 255)
        bold:bool = False
        italic:bool = False

        pic:str = ""  # picture, through .pic
        p_just:(dx, dy) = (0, 0)
        scale:int = 100

        text:str = ""  # text, through .text
        t_just:(dx, dy) = (0, 0)

        focus:str = ""  # controller name, ctrl type must be 'focus'
        cover:str = ""  # extra pic when focus, , through .cover

    """

    def Loading(self, **kwargs):
        super().Loading(**kwargs)
        self.LogController(kwargs['ctrl'])


# --------------------------------------------------------Anim 分界线----------------------------------------------------------
# 用户用State和Node写， 我们转换成列表来做

class State(object):  # 状态-对质点-无绑定
    """
    实例方式:
        State(pos:(cx, cy), scale, rotate)
    """

    def __init__(self, cpos: tuple, scale=100, rotate=0, vf=0, hf=0):
        self._data = [*cpos, scale, rotate, vf, hf]
        self.index = 0

    def _get_(self, index):
        return self._data[index]

    def _set_(self, index, value):
        self._data[index] = value

    cx = property(lambda self: State._get_(self, 0), lambda self, value: State._set_(self, 0, value))
    cy = property(lambda self: State._get_(self, 1), lambda self, value: State._set_(self, 1, value))
    scale = property(lambda self: State._get_(self, 2), lambda self, value: State._set_(self, 2, value))
    s = scale
    rotate = property(lambda self: State._get_(self, 3), lambda self, value: State._set_(self, 3, value))
    r = rotate
    vflip = property(lambda self: State._get_(self, 4), lambda self, value: State._set_(self, 4, value))
    vf = vflip
    hflip = property(lambda self: State._get_(self, 5), lambda self, value: State._set_(self, 5, value))
    hf = hflip

    def __iter__(self):
        return self

    def __next__(self):
        if self.index != len(self._data):
            self.index += 1
            return self._data[self.index - 1]
        else:
            self.index = 0
            raise StopIteration


class Node(object):  # 节点-对质点-有绑定
    """
    表示某spirit保持某种state并持续一段ct
    """

    def __init__(self, spirit=None, state=None, ct: int = None, name=None, *tags):
        """
        创建节点
        :param inst: obj(Node)上一节点
        :param data: obj(Data)全局变量环境
        :param spirit: obj(Component)动画元素
        :param state: obj(State)状态
        :param ct: int持续时间，单位 帧
        :param name: str<None>节点名称
        """
        if spirit is None or state is None or ct is None:
            if not (spirit is None and state is None and ct is None): raise ValueError("前三项属性要么都为None要么都不为None")
        self._data = [spirit, state, ct, name]
        self.inst = None
        self.data = None
        self._subs = []
        self._tags = tags
        self.index = 0

    def _get_(self, index):
        return self._data[index]

    def _set_(self, index, value):
        self._data[index] = value

    spirit = property(lambda self: Node._get_(self, 0), lambda self, value: Node._set_(self, 0, value))
    pic = spirit
    state = property(lambda self: Node._get_(self, 1), lambda self, value: Node._set_(self, 1, value))
    ct = property(lambda self: Node._get_(self, 2), lambda self, value: Node._set_(self, 2, value))
    name = property(lambda self: Node._get_(self, 3), lambda self, value: Node._set_(self, 3, value))

    def IsAble(self):
        return self.data is not None and self.inst is not None

    def Break(self):
        """
        将自身与上一级孤立
        :return:
        """
        self.inst = None

    def ChangeTo(self, inst, data=None):
        """
        加载自身到到指定链
        :param inst: 上一级
        :param data: 数据
        :return:
        """
        self.inst = inst
        self.data = data if data else self.data

    LoadTo = ChangeTo

    def AsHead(self, data):
        if not self.IsAble():
            self.LoadTo(None, data)
        else:
            return False

    def GetSub(self, name):
        """
        获取指定名称的节点
        :param name: str 欲访问的节点的名称
        :return: None or Node
        """
        if not name: return
        for node in self._subs:
            if node.name == name: return node

    def GetSubs(self, tag=None):
        """
        获取带有tag标签的所有节点，tag为None时返回所有
        :param tag: str<None> 欲筛选节点名
        :return: list(Node)
        """
        if not tag: return self._subs.copy()
        temp = []
        for node in self._subs:
            if tag in node.GetTags():
                temp += [node]
        return temp

    def AddSub(self, sub):
        """
        添加一个sub
        :param sub: instance of Node
        :return:
        """
        sub.ChangeTo(self, self.data)
        self._subs += [sub]

    def AddSubs(self, *subs):
        """
        添加一组sub
        :param subs: tuple of subs
        :return:
        """
        for sub in subs:
            self.AddSub(sub)

    def RmSub(self, name):
        """
        移除节点
        :param name: str 节点名称
        :return:
        """
        if not name: return
        for node in self._subs:
            if node.name == name: return self._subs.remove(node)

    def RmSubyTags(self, *tags):
        """
        移除节点
        :param tags: tuple of str 节点名称
        :return:
        """
        if not tags: return
        all_i = []
        for i in range(len(self._subs)):
            for t in tags:
                if t in self._subs[i].GetTags():
                    all_i += [i]

        all_i.reverse()
        for i in all_i:
            del self._subs[i]

    def GetTags(self):
        """
        获取自身所有tag
        :return:
        """
        return self._tags

    def AddTag(self, tag):
        """
        为自身添加tag
        :param tag: str
        :return:
        """
        self._tags += [tag]

    def AddTags(self, *tags):
        """
        为自身添加一组tag
        :param tags:
        :return:
        """
        for t in tags:
            self.AddTag(t)

    def __iter__(self):
        return self

    def __next__(self):
        if self.index != len(self._data):
            self.index += 1
            if self.index - 1 == 1:  # state时返回list(state)
                return list(self._data[self.index - 1])
            if self.index - 1 == 2:  # 跳过ct
                self.index += 1
            return self._data[self.index - 1]
        else:
            self.index = 0
            raise StopIteration

    def __call__(self, *subs):
        self.AddSubs(*subs)


class Anim(BaseView):
    """
    一个特殊的View，失去了大部分view的功能，然后添加了一些View所不具有的特性
    比View更精简，有利于节约程序资源
    与View相比，Anim
    *取消各种view方法
    *不能参与event(的接收)和periodic task
    *不能参与控制器响应
    *取消AddComponent、GetComponent、GetComponents、RemoveComponent函数，取而代之的是AddSpirit、GetSpirit、GetSpirits、RemoveSpirit
    *只支持Pic组件(Spirit在本质上是一个Pic组件)

    !!!所有动画在加载时会全部加载一遍，这将大大加大加载时间和内存占用!!!
    """

    def __init__(self, data, inst=None, __system_calling_trig__=False, view_id=None, **kwargs):
        super().__init__(data, inst, view_id, **kwargs)

        if kwargs.get("-spirits"):
            for i in kwargs["-spirits"]:
                self.AddSpirit(i[0], **i[1])

        self.TypeView = "Anim"
        self._kwargs = kwargs
        self._time = list()  # 时间轴[(若干元素...), (...), (...)], 元素形如(spirit, (cx, cy, s, r, v, h), ct, event)
        self.__system_calling_trig__ = __system_calling_trig__
        if not __system_calling_trig__:  # 我已经看不懂在干嘛了2333
            self.Loading(**kwargs)
            self.data.SysGetWinManage().AddQueue("HappenEnabled", view=self)
            if self.inst and self.size == data.st.DEFAULT_WINDOW_SIZE:
                warn(Warning(self.__class__.__name__ + "doesn' t set size, it will use the default size in setting."))

        # -- Anim独特的重要的属性
        self._df = "Default"
        self._speed = 100
        self._tRec = 0  # 记录当前的时间进度
        self._rl = 2

    def Config(self, **kwargs):
        """
        available:
            df:str = "Default"  # 配置默认动画
            speed:int = 100  # 速度，默认100%
            rl:int = 2  # 粗糙度，默认2(取值>=1, 1对应完全补间，n对应1/n补间(例n=10时对应10%补间))，越粗糙对资源占用越低
        # !注意: 为减少资源占用PgFrame并不会进行类型检查，请保证类型的正确性
        :param kwargs: 参数
        :return:
        """

        def cf(k):
            t = kwargs.get(k)
            if k: setattr(self, "_" + k, t)

        avs = ["df", "speed", "rl"]
        for k in avs: cf(k)

    def Loading(self, **kwargs):
        """
        用户在这里写自己的额外的初始化代码
        Users write their own additional initialization code here
        :param kwargs: **dict --> 自动传递__init__中的kwargs
        :return: None
        """
        pass

    def Default(self):
        """
        Anim特殊状态设置函数，设置动画的默认状态
        当Anim被创建完成后自动执行，将动画调整为默认状态
        :return:list  一段由AnimManager创建的动画数据
        """
        pass

    def system_redo(self):
        """
        系统调用，用户调用可能导致bug
        :return: None
        """
        if self.auto and self.__system_calling_trig__:
            self.Loading(**self._kwargs)
            if self.inst and self.size == self.data.st.DEFAULT_WINDOW_SIZE:
                warn(Warning(self.__class__.__name__ + "doesn' t set size, it will use the default size in setting."))

    def __fill__(self, _data, _time, temporary_rl=None):
        """
        填充执行区间，直接在data和time上改
        :param _data: list 由LoadAnim创建的Animdata数据[[(spirit, (cx, cy, s, r, v, h), ct, event), ]]
        :param _time: list 由LoadAnim创建的时间轴数据
        :param temporary_rl: int 由用户指定的临时粗糙度设定
        :return: None
        """

        def fn001(_d1, _d2):
            ...

        # _data的第一个数据即为初始状态
        _len = len(_time)
        for index in range(_len):  # <index>对每个时间点进行索引
            if index == _len - 1: ...  # 最后一部分, 无需拷贝，节约资源
            #for ele in _data[index]  # 这里需要同一个元素的行为！！！！！！！！！！！！！！！！！！！
            delta = fn001(_data[index], _data[index + 1])  # 获取两帧间差异
            for i in range(index):  # 0 ~ index-1循环，共index次
                ...

    def __call__(self, *args, **kwargs):
        pass

    def PushEvent(self, event_name, **kwargs):  # id must > 24
        """
        通过根视图触发指定事件
        Trigger the specified event through the root view
        :param event_name: string --> 事件名称 Event Name
        :param kwargs: **dict --> 事件的参数键值对 Parameter key-value pairs for _events
        :return: None
        """
        if self.inst is not None:
            self.inst.PushEvent(event_name, **kwargs)
        else:
            self.data.SysGetEveManage().PushEvent(self, event_name, **kwargs)

    def LoadAnim(self, intro: Node):
        """
        加载动画为可执行数据, 并将其装载到时间轴中，如果时间轴被占用，则装载失败
        失败返回False
        成功返回True
        思路： 使用一个列表将所有动画flatten, 另一个列表储存该动画自被创建到执行的帧数
        :param intro: Node 动画入口, 头结点
        :return: list 时间轴数据[(ele, ...), ...]
        """
        _data, _time = [], []

        def insert(_d: list, _t: list, d: object, t: int):
            if not _t:
                _d += [[d]]
                _t += [t]
                return

            if t >= _t[-1]:
                if t == _t[-1]:
                    _d[-1] += [d]
                else:  # t > _t[-1]
                    _d += [[d]]
                _t += [t]
                return

            _len = len(_t)
            for i in range(1, _len + 1):
                if t == _t[-i]:
                    _t.insert(-i, t)
                    _d[-i] += [d]
                    return

                if i == _len or _t[-i - 1] < t < _t[-i]:  # 这个是后期合并的
                    _t.insert(-i, t)
                    _d.insert(-i, [d])
                    return

        def fn(_d: list, _t: list, node: Node, wt: int):
            """
            解析一个节点的数据到_data和_time中，并启动其子节点的fn函数
            :param _d: list _data
            :param _t: list _time
            :param node: Node 节点
            :param wt: int 执行该节点时已进行了的时间
            :return: None
            """
            if node.IsAble():
                insert(_d, _t, list(node), wt)
            for n in node.GetSubs():
                fn(_d, _t, n, n.ct + wt)

        fn(_data, _time, intro, 0)
        return _data, _time

    def ExecuteInTime(self, codes, tick):
        """
        Anim特殊方法，可以按行匀速执行code中的代码，环境在Update函数下(可使用self变量)
        是anim能实现动画的保障
        :param codes: list(Str...) 程序代码，可以使用\n换行
        :param tick: Int 总帧数(在多少帧内完成这段代码)
        :return: None
        """
        per_tick = (tick / len(codes) + .5) // 1
        self._wait += [(codes, per_tick)]

    def AddQueue(self, func, **kwargs):
        """
        添加队列任务,但是你无法获得返回值
        :param func: String/Func 函数名/函数
        :param kwargs: **dict参数键值对
        :return: None
        """
        self._queue.append((func, kwargs))

    def AddSpirit(self, ArtDef, sign=None, show=True, scale="100", rotate="000", hflip="0", vflip="0", tim=0,
                  keep_tim=0, justify=(0, 0), end_func=None, center=True):
        """
        为当前视图添加图片元素
        Add spirit for Current Anim
        :param ArtDef: 艺术数据名String
        :param sign: String 设置图片元素在inst中的变量名称,None表示不添加
        :param show: Bool 设置图片元素是否可见
        :param scale: 缩放倍率Int 0~100 (100->100%, 10->10%)(传入String类型能减少程序资源占用)
        :param rotate: 旋转角度Int 0~360 (向上为0, 顺时针旋转)(传入String类型能减少程序资源占用)
        :param hflip: 水平翻转Int 0/1(1表示水平翻转)(传入String类型能减少程序资源占用)
        :param vflip: 竖直翻转Int 0/1(1表示竖直翻转)(传入String类型能减少程序资源占用)
        :param tim: 图片间隔帧Int(只适用于多图片,控制图片播放时间隔的帧数)
        :param keep_tim: 持续帧数Int(显示多少帧，大于此数时，该组件会被隐藏)
        :param justify: Tuple(int, int) 图片位置微调
        :param end_func: function(pic= Pic Components) 允许Pic即将Hide时激活函数
        :param center: 是否以中心为基准点Bool(传入False能减少程序资源占用), 默认True
        :return: int --> 元素的id ID of spirit
        """
        self._components[self._cp_id] = getattr(self.data.cp, "Pic")(self, ArtDef=ArtDef, scale=scale, rotate=rotate, hflip=hflip, vflip=vflip,
                                                                     tim=tim, keep_tim=keep_tim, justify=justify, sign=sign, end_func=end_func,
                                                                     center=center)
        if not show:
            self._components[self._cp_id].Hide()
        self._cp_id += 1
        return self._cp_id - 1

    def GetSpirits(self):
        """
        获取所有的图片元素
        Get all _spirits
        :return: list --> 实例化图片元素列表 List of instantiated _spirits
        """
        return self._components.values()

    def GetSpirit(self, spirit_id):
        """
        获取指定的图片元素
        Gets the specified spirit
        :param spirit_id: int --> 图片元素的id ID of spirit
        :return: object --> 实例化图片元素 instantiated spirit
        """
        return self._components[spirit_id]

    def RemoveSpirit(self, spirit_id):
        """
        移除指定的图片元素
        Remove the specified spirit
        :param spirit_id: int --> 组件的id ID of spirit
        :return: None
        """
        self._components[spirit_id].remove()
        del self._components[spirit_id]

    def Update(self):
        """
        更新视图
        特别的，Anim会在一个额外的线程中进行
        Update the current view.
        :return: None
        """
        data = self.data
        # _quene
        if self._queue:
            for i in self._queue:
                if isinstance(i[0], str):
                    getattr(self, i[0])(**i[1])
                else:
                    i[0](**i[1])
            self._queue = []
        # _wait
        for codes, p_tick in self._wait:
            if not codes:
                self._wait.remove((codes, p_tick))
                continue
            if self.data.SysGetTick() % p_tick == 0:
                exec(codes.pop(0))

        # _time

        data.SysGetCore().GetViewAtPosition(data, self)
        data.SysGetCore().UpdateView(data, self)


if __name__ == '__main__':
    s1 = State((0, 0))
    s2 = State((100, 100), rotate=60)
    s3 = State((200, 0), rotate=-60)
    head = Node()
    n0 = Node(object(), s1, 50)
    n0_2 = Node(object(), s2, 30)
    n1 = Node(object(), s2, 20)
    n1_2 = Node(object(), s2, 20)
    n2 = Node(object(), s3, 30)
    n3 = Node(object(), s1, 40)

    head.AsHead(object())
    head(n0)
    n0(n1)
    n0(n0_2)
    n0_2(n1_2)
    n1(n2)
    n2(n3)
    print(Anim.LoadAnim(head))
