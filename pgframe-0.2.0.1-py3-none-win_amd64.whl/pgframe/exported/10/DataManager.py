# 这是一个用户文件
"""
打开时会自动更新model
"""
from pgframe.DataManager import DataManager
import models
import settings

DataManager(models,settings).Start()