import traceback as tb
import sys


class Error(Exception):
    def __init__(self, *reasons):
        txt = "\n\n"
        txt += "Error -> {}:\n".format(self.__class__.__name__)
        for item in reasons:
            txt += "\t" + str(item) + "\n"
        super(Error, self).__init__(txt)
        # print(sys.exc_info())  # 只有当异常发生后才能获取到信息


# 系统类错误
class UnCompatiblePlatform(Error):
    def __init__(self, system):
        super(UnCompatiblePlatform, self).__init__("pgframe only support Windows system", "do not support platform as {}.".format(system))


class NotDir(Error):
    def __init__(self, path):
        super(NotDir, self).__init__("path <{}> is not a directory.".format(path), "please repair it and try again.")


class NotFile(Error):
    def __init__(self, path):
        super(NotFile, self).__init__("path <{}> is not a file.".format(path), "please repair it and try again.")


class UnSupportType(Error):
    def __init__(self, variable_name: str, type_need: str, type_get: str):
        super(UnSupportType, self).__init__(
            "变量 '{}' 的类型发生错误".format(variable_name),
            "这里需要一个 '{}' 类型的数据".format(type_need),
            "但是程序执行时发现它是一个 '{}' 类型的数据".format(type_get),
        )


class RepeatImgFileName(Error):
    def __init__(self, filepath):
        super(RepeatImgFileName, self).__init__("file <{}> has been loaded before.".format(filepath),
                                                "pgframe do not allow two picture has the same name with different path")


# 数据错误
class UnSupportValue(Error):
    def __init__(self, variable_name: str, all_support: list, actually_get: str):
        super(UnSupportValue, self).__init__(
            "变量 '{}' 的数据不是被支持的预设值".format(variable_name),
            "该类型所有的预设值为:",
            *["\t" + str(i) for i in all_support],
            "实际上该变量的值为 '{}'".format(actually_get),
        )


class MissingAttributes(Error):
    def __init__(self, cls, *attr_names):
        super(MissingAttributes, self).__init__(
            "在class '{}' 中缺失了以下必要的属性:".format(cls),
            *["\t" + str(i) for i in attr_names]
        )


class MultipleKey(Error):
    def __init__(self, r_name, *args):
        super(MultipleKey, self).__init__("检测到有多个键重复,重复的key为{}".format(r_name), *args)


class NeedInit(Error):
    def __init__(self, part, method, *args):
        super(NeedInit, self).__init__("模块{}需要事先通过{}进行初始化".format(part, method), *args)
# raise MissingAttributes("JeyCtrl", "'TypeKey' or", "'TypeMouse' or", "'TypeMouseMove'", "at least one of them")
# try:
#     raise NotDir("E://")
# except:
#     print(dir(sys.exc_info()[2])
#           )
